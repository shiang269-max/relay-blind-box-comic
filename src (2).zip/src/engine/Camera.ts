export class Camera {
  public x = 0;
  public y = 0;
  public scale = 1;

  private viewportWidth = 0;
  private viewportHeight = 0;

  constructor(
    public readonly worldWidth: number,
    public readonly worldHeight: number
  ) {}

  setViewport(width: number, height: number) {
    this.viewportWidth = width;
    this.viewportHeight = height;
    this.clamp();
  }

  setPosition(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.clamp();
  }

  move(dx: number, dy: number) {
    this.x += dx;
    this.y += dy;
    this.clamp();
  }

  zoom(scale: number) {
    this.scale = Math.min(1, Math.max(0.2, scale));
    this.clamp();
  }

  getViewWidth() {
    return this.viewportWidth / this.scale;
  }

  getViewHeight() {
    return this.viewportHeight / this.scale;
  }

  getTransform() {
    return {
      scale: this.scale,
      translateX: -this.x * this.scale,
      translateY: -this.y * this.scale,
    };
  }

  screenToWorld(screenX: number, screenY: number) {
    return {
      x: this.x + screenX / this.scale,
      y: this.y + screenY / this.scale,
    };
  }

  screenToWorld(screenX: number, screenY: number) {
    return {
      x: this.x + screenX / this.scale,
      y: this.y + screenY / this.scale,
    };
  }

  worldToScreen(worldX: number, worldY: number) {
    return {
      x: (worldX - this.x) * this.scale,
      y: (worldY - this.y) * this.scale,
    };
  }

  private clamp() {
    const maxX = Math.max(0, this.worldWidth - this.getViewWidth());
    const maxY = Math.max(0, this.worldHeight - this.getViewHeight());

    this.x = Math.min(Math.max(this.x, 0), maxX);
    this.y = Math.min(Math.max(this.y, 0), maxY);
  }
}