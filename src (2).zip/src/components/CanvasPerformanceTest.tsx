 import { useEffect, useRef } from "react";
 import { Camera } from "../engine/Camera";

const WORLD_WIDTH = 3000;
const WORLD_HEIGHT = 5000;

const FRICTION = 0.92;
const MIN_SPEED = 0.05;

const MIN_SCALE = 0.2;
const MAX_SCALE = 1;

export default function CanvasPerformanceTest() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const cameraEngineRef = useRef(
    new Camera(WORLD_WIDTH, WORLD_HEIGHT)
  );

  const cameraRef = useRef({
    x: 0,
    y: 0,
    scale: 1,
  });

  const velocityRef = useRef({
    x: 0,
    y: 0,
  });

  const dragRef = useRef({
    dragging: false,
    startPointerX: 0,
    startPointerY: 0,
    startCameraX: 0,
    startCameraY: 0,
    lastPointerX: 0,
    lastPointerY: 0,
    lastTime: 0,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId = 0;

    const clampCamera = () => {
      cameraEngineRef.current.scale = cameraRef.current.scale;
      cameraEngineRef.current.setPosition(
        cameraRef.current.x,
        cameraRef.current.y
      );

      cameraRef.current.x = cameraEngineRef.current.x;
      cameraRef.current.y = cameraEngineRef.current.y;

      if (
        cameraRef.current.x === 0 ||
        cameraRef.current.x ===
          WORLD_WIDTH - canvas.width / cameraRef.current.scale
      ) {
        velocityRef.current.x = 0;
      }

      if (
        cameraRef.current.y === 0 ||
        cameraRef.current.y ===
          WORLD_HEIGHT - canvas.height / cameraRef.current.scale
      ) {
        velocityRef.current.y = 0;
      }
    };

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = "#202020";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

   ctx.save();

ctx.scale(cameraRef.current.scale, cameraRef.current.scale);

ctx.translate(
  -cameraRef.current.x,
  -cameraRef.current.y
);

ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 4;
      ctx.strokeRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

      ctx.strokeStyle = "#e5e5e5";
      ctx.lineWidth = 1;

      for (let x = 0; x <= WORLD_WIDTH; x += 100) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, WORLD_HEIGHT);
        ctx.stroke();
      }

      for (let y = 0; y <= WORLD_HEIGHT; y += 100) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(WORLD_WIDTH, y);
        ctx.stroke();
      }

      ctx.restore();

      ctx.fillStyle = "rgba(0,0,0,0.7)";
      ctx.fillRect(10, 10, 220, 80);

      ctx.fillStyle = "#ffffff";
      ctx.font = "16px sans-serif";
      ctx.fillText(`Camera X: ${Math.round(cameraRef.current.x)}`, 20, 35);
      ctx.fillText(`Camera Y: ${Math.round(cameraRef.current.y)}`, 20, 58);
      ctx.fillText(
        `Speed: ${Math.hypot(
          velocityRef.current.x,
          velocityRef.current.y
        ).toFixed(2)}`,
        20,
        81
      );
    };

    const update = () => {
      if (!dragRef.current.dragging) {
        cameraRef.current.x += velocityRef.current.x;
        cameraRef.current.y += velocityRef.current.y;

        velocityRef.current.x *= FRICTION;
        velocityRef.current.y *= FRICTION;

        if (Math.abs(velocityRef.current.x) < MIN_SPEED) {
          velocityRef.current.x = 0;
        }

        if (Math.abs(velocityRef.current.y) < MIN_SPEED) {
          velocityRef.current.y = 0;
        }

        clampCamera();
      }

      render();
      animationId = requestAnimationFrame(update);
    };

    const resize = () => {
      canvas.width = window.innerWidth;
       canvas.height = window.innerHeight;
       cameraEngineRef.current.setViewport(canvas.width, canvas.height);
       clampCamera();
     };

     const pointerDown = (e: PointerEvent) => {
      dragRef.current.dragging = true;
      dragRef.current.startPointerX = e.clientX;
      dragRef.current.startPointerY = e.clientY;
      dragRef.current.startCameraX = cameraRef.current.x;
      dragRef.current.startCameraY = cameraRef.current.y;
      dragRef.current.lastPointerX = e.clientX;
      dragRef.current.lastPointerY = e.clientY;
      dragRef.current.lastTime = performance.now();

      velocityRef.current.x = 0;
      velocityRef.current.y = 0;

      canvas.setPointerCapture(e.pointerId);
    };

    const pointerMove = (e: PointerEvent) => {
      if (!dragRef.current.dragging) return;

      const dx = e.clientX - dragRef.current.startPointerX;
      const dy = e.clientY - dragRef.current.startPointerY;

      cameraRef.current.x = dragRef.current.startCameraX - dx;
      cameraRef.current.y = dragRef.current.startCameraY - dy;

      clampCamera();

      const now = performance.now();
      const dt = Math.max(now - dragRef.current.lastTime, 1);

      velocityRef.current.x =
        -(e.clientX - dragRef.current.lastPointerX) / dt * 16;
      velocityRef.current.y =
        -(e.clientY - dragRef.current.lastPointerY) / dt * 16;

      dragRef.current.lastPointerX = e.clientX;
      dragRef.current.lastPointerY = e.clientY;
      dragRef.current.lastTime = now;
    };

   const wheel = (e: WheelEvent) => {
  e.preventDefault();

  const mouseX = e.offsetX;
  const mouseY = e.offsetY;

  const { x: worldX, y: worldY } = cameraEngineRef.current.screenToWorld(
    mouseX,
    mouseY
  );

  const zoomSpeed = 0.05;

  const oldScale = cameraRef.current.scale;

  if (e.deltaY < 0) {
    cameraRef.current.scale = Math.min(
      MAX_SCALE,
      oldScale + zoomSpeed
    );
  } else {
    cameraRef.current.scale = Math.max(
      MIN_SCALE,
      oldScale - zoomSpeed
    );
  }

  cameraRef.current.x =
    worldX - mouseX / cameraRef.current.scale;

  cameraRef.current.y =
    worldY - mouseY / cameraRef.current.scale;

  clampCamera();
};
    const pointerUp = (e: PointerEvent) => {
      dragRef.current.dragging = false;

      if (canvas.hasPointerCapture(e.pointerId)) {
        canvas.releasePointerCapture(e.pointerId);
      }
    };

    window.addEventListener("resize", resize);

    canvas.addEventListener("pointerdown", pointerDown);
    canvas.addEventListener("pointermove", pointerMove);
    canvas.addEventListener("pointerup", pointerUp);
    canvas.addEventListener("pointercancel", pointerUp);
    canvas.addEventListener("pointerleave", pointerUp);
    canvas.addEventListener("wheel", wheel, { passive: false });

    resize();
    update();

    return () => {
      cancelAnimationFrame(animationId);

      window.removeEventListener("resize", resize);

      canvas.removeEventListener("pointerdown", pointerDown);
      canvas.removeEventListener("pointermove", pointerMove);
      canvas.removeEventListener("pointerup", pointerUp);
      canvas.removeEventListener("pointercancel", pointerUp);
      canvas.removeEventListener("pointerleave", pointerUp);
      canvas.removeEventListener("wheel", wheel);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        display: "block",
        width: "100vw",
        height: "100vh",
        touchAction: "none",
        cursor: "grab",
        background: "#202020",
      }}
    />
  );
}